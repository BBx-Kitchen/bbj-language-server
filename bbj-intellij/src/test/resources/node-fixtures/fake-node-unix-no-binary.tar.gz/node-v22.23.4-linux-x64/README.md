Node.js v22.23.4 readme (fixture)
