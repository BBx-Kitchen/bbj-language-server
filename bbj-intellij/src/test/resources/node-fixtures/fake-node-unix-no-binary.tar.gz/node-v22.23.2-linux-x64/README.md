Node.js v22.23.2 readme (fixture)
