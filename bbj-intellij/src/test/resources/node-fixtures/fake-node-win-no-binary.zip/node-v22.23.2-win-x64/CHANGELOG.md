Node.js v22.23.2 changelog (fixture)
