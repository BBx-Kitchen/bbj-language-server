Node.js v22.23.4 changelog (fixture)
